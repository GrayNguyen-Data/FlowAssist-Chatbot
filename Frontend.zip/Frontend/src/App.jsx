import { NavLink, Route, Routes, Navigate } from "react-router-dom";
import { useAuth } from "./contexts/AuthContext";
import DashboardPage from "./pages/DashboardPage";
import ChatPage from "./pages/ChatPage";
import DocumentsPage from "./pages/DocumentsPage";
import LoginPage from "./pages/LoginPage";

const NAV_ITEMS_ADMIN = [
  { to: "/", label: "Dashboard", icon: "🏠", end: true },
  { to: "/chat", label: "Chat", icon: "💬" },
  { to: "/documents", label: "Documents", icon: "📚" },
];

const NAV_ITEMS_USER = [
  { to: "/", label: "Dashboard", icon: "🏠", end: true },
  { to: "/chat", label: "Chat", icon: "💬" },
];

function Sidebar() {
  const { role, username, isAdmin, logout } = useAuth();
  const items = isAdmin ? NAV_ITEMS_ADMIN : NAV_ITEMS_USER;

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <span className="logo-mark">⚡</span>
        <span className="logo-name">FlowAssist</span>
      </div>

      <div className="sidebar-user">
        <div className="sidebar-avatar">{isAdmin ? "🛡️" : "👤"}</div>
        <div className="sidebar-user-info">
          <div className="sidebar-username">{username}</div>
          <div className={`sidebar-role-tag ${role}`}>{isAdmin ? "Admin" : "User"}</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        <div className="nav-section-label">Menu</div>
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
          >
            <span className="nav-icon">{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <button className="logout-btn" onClick={logout}>
          <span>🚪</span> Đăng xuất
        </button>
      </div>
    </aside>
  );
}

function ProtectedLayout() {
  const { isAdmin } = useAuth();
  return (
    <div className="app-shell">
      <Sidebar />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/chat" element={<ChatPage />} />
          {isAdmin && <Route path="/documents" element={<DocumentsPage />} />}
          {!isAdmin && <Route path="/documents" element={<Navigate to="/" replace />} />}
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  const { role } = useAuth();
  if (!role) return <LoginPage />;
  return <ProtectedLayout />;
}