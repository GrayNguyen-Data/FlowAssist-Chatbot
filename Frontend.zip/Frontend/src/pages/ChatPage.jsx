import { useEffect, useMemo, useRef, useState } from "react";
import {
  createConversation,
  getConversationMessages,
  sendChatMessage,
} from "../api/chatAPI";
import { useAuth } from "../contexts/AuthContext";

const RECENTS_KEY = "flowassist_recent_conversations";
const ACTIVE_ID_KEY = "flowassist_conversation_id";
const ACTIVE_TITLE_KEY = "flowassist_conversation_title";

function makeConversationTitle(text) {
  const clean = (text || "").replace(/\s+/g, " ").trim();
  if (!clean) return "New conversation";
  return clean.length > 42 ? `${clean.slice(0, 42)}...` : clean;
}

function sortRecents(items) {
  return [...items].sort((a, b) => {
    const ta = new Date(a.updatedAt || 0).getTime();
    const tb = new Date(b.updatedAt || 0).getTime();
    return tb - ta;
  });
}

function readRecents() {
  try {
    const raw = localStorage.getItem(RECENTS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? sortRecents(parsed) : [];
  } catch {
    return [];
  }
}

function writeRecents(items) {
  localStorage.setItem(RECENTS_KEY, JSON.stringify(sortRecents(items)));
}

function upsertRecentConversation({ id, title, updatedAt }) {
  const current = readRecents();
  const next = current.filter((item) => item.id !== id);
  next.unshift({
    id,
    title: title || "New conversation",
    updatedAt: updatedAt || new Date().toISOString(),
  });
  writeRecents(next);
  return sortRecents(next);
}

function removeRecentConversation(id) {
  const next = readRecents().filter((item) => item.id !== id);
  writeRecents(next);
  return next;
}

function MessageBubble({ role, content }) {
  return (
    <div className={`chat-bubble-row ${role === "error" ? "assistant" : role}`}>
      <div className={`chat-avatar ${role === "error" ? "error" : role}`}>
        {role === "user" ? "👤" : role === "error" ? "⚠️" : "🤖"}
      </div>

      <div className="chat-bubble-wrap">
        <div className={`chat-bubble ${role}`}>{content}</div>
      </div>
    </div>
  );
}

export default function ChatPage() {
  const { isAdmin } = useAuth();

  const [conversationId, setConversationId] = useState("");
  const [conversationTitle, setConversationTitle] = useState("New conversation");
  const [recentConversations, setRecentConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [retrievedContext, setRetrievedContext] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [booting, setBooting] = useState(true);
  const [bootError, setBootError] = useState(null);
  const [showContext, setShowContext] = useState(false);

  const messagesEndRef = useRef(null);

  const persistActiveConversation = (id, title) => {
    setConversationId(id);
    setConversationTitle(title || "New conversation");
    localStorage.setItem(ACTIVE_ID_KEY, id);
    localStorage.setItem(ACTIVE_TITLE_KEY, title || "New conversation");
  };

  const syncRecent = (id, title) => {
    const next = upsertRecentConversation({
      id,
      title,
      updatedAt: new Date().toISOString(),
    });
    setRecentConversations(next);
  };

  const createNewConversation = async (title = "New conversation") => {
    const created = await createConversation({
      userId: "default",
      title,
      channel: "chat",
    });

    const id = created.conversation_id;
    const finalTitle = created.title || title;

    persistActiveConversation(id, finalTitle);
    syncRecent(id, finalTitle);
    setMessages([]);
    setRetrievedContext([]);
    return id;
  };

  const loadConversation = async (id, titleFromRecent = "New conversation") => {
    setLoading(true);
    setBootError(null);

    try {
      const history = await getConversationMessages(id);

      setMessages(
        Array.isArray(history)
          ? history.map((item) => ({
              id: item.message_id,
              role: item.role,
              content: item.content,
            }))
          : []
      );

      persistActiveConversation(id, titleFromRecent);
      syncRecent(id, titleFromRecent);
      setRetrievedContext([]);
    } catch (error) {
      setBootError(error.message || "Không tải được conversation.");
      const next = removeRecentConversation(id);
      setRecentConversations(next);

      if (localStorage.getItem(ACTIVE_ID_KEY) === id) {
        localStorage.removeItem(ACTIVE_ID_KEY);
        localStorage.removeItem(ACTIVE_TITLE_KEY);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const bootstrap = async () => {
      try {
        const recents = readRecents();
        setRecentConversations(recents);

        const savedId = localStorage.getItem(ACTIVE_ID_KEY);
        const savedTitle = localStorage.getItem(ACTIVE_TITLE_KEY) || "New conversation";

        if (savedId) {
          await loadConversation(savedId, savedTitle);
        } else if (recents.length > 0) {
          await loadConversation(recents[0].id, recents[0].title);
        } else {
          await createNewConversation("New conversation");
        }
      } catch (error) {
        setBootError(error.message || "Không thể kết nối tới server.");
      } finally {
        setBooting(false);
      }
    };

    bootstrap();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const canSend = useMemo(
    () => !!input.trim() && !!conversationId && !loading,
    [input, conversationId, loading]
  );

  const handleNewConversation = async () => {
    try {
      setLoading(true);
      await createNewConversation(`Chat ${new Date().toLocaleTimeString()}`);
    } catch (error) {
      setBootError(error.message || "Không tạo được conversation mới.");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectConversation = async (item) => {
    if (!item?.id || item.id === conversationId) return;
    await loadConversation(item.id, item.title);
  };

  const handleDeleteConversation = async (e, id) => {
    e.stopPropagation();

    const next = removeRecentConversation(id);
    setRecentConversations(next);

    if (id === conversationId) {
      setMessages([]);
      setRetrievedContext([]);
      localStorage.removeItem(ACTIVE_ID_KEY);
      localStorage.removeItem(ACTIVE_TITLE_KEY);

      if (next.length > 0) {
        await loadConversation(next[0].id, next[0].title);
      } else {
        try {
          setLoading(true);
          await createNewConversation("New conversation");
        } catch (error) {
          setBootError(error.message || "Không tạo được conversation mới.");
        } finally {
          setLoading(false);
        }
      }
    }
  };

  const handleSend = async () => {
    if (!canSend) return;

    const userText = input.trim();
    const isFirstUserMessage = messages.filter((m) => m.role === "user").length === 0;
    const derivedTitle = isFirstUserMessage ? makeConversationTitle(userText) : conversationTitle;

    setInput("");
    setLoading(true);

    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        role: "user",
        content: userText,
      },
    ]);

    try {
      if (isFirstUserMessage) {
        setConversationTitle(derivedTitle);
        localStorage.setItem(ACTIVE_TITLE_KEY, derivedTitle);
        syncRecent(conversationId, derivedTitle);
      } else {
        syncRecent(conversationId, conversationTitle);
      }

      const response = await sendChatMessage({
        conversationId,
        message: userText,
      });

      setMessages((prev) => [
        ...prev,
        {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: response.assistant_message,
        },
      ]);

      setRetrievedContext(response.retrieved_context || []);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: "error",
          content: `⚠️ Lỗi: ${error.message || "Backend trả về lỗi."}`,
        },
      ]);
      setBootError(error.message || "Không gửi được tin nhắn.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (booting) {
    return (
      <div className="chat-boot">
        <div className="chat-boot-spinner" />
        <p>Đang kết nối tới server...</p>
      </div>
    );
  }

  if (bootError && !conversationId) {
    return (
      <div className="chat-boot">
        <div className="boot-error-icon">⚠️</div>
        <p className="boot-error-title">Không thể khởi động Chat</p>
        <p className="boot-error-msg">{bootError}</p>
        <button
          className="button"
          onClick={() => {
            setBootError(null);
            setBooting(true);
            window.location.reload();
          }}
        >
          🔄 Thử lại
        </button>
      </div>
    );
  }

  return (
    <div className="chat-shell">
      <div className="chat-sidebar">
        <div className="chat-sidebar-head">
          <span className="chat-sidebar-title">Recents</span>
          <button
            className="btn-new-conv"
            onClick={handleNewConversation}
            disabled={loading}
            title="Tạo mới"
          >
            ＋
          </button>
        </div>

        <div className="conv-list">
          {recentConversations.length === 0 ? (
            <div className="conv-empty">Chưa có hội thoại nào.</div>
          ) : (
            recentConversations.map((item) => (
              <div
                key={item.id}
                className={`conv-item ${item.id === conversationId ? "active" : ""}`}
                onClick={() => handleSelectConversation(item)}
              >
                <div className="conv-main">
                  <div className="conv-name">{item.title || "New conversation"}</div>
                  <div className="conv-time">
                    {item.updatedAt
                      ? new Date(item.updatedAt).toLocaleString("vi-VN")
                      : ""}
                  </div>
                </div>

                <button
                  className="conv-delete-btn"
                  onClick={(e) => handleDeleteConversation(e, item.id)}
                  title="Xóa khỏi danh sách gần đây"
                >
                  ×
                </button>
              </div>
            ))
          )}
        </div>

        {isAdmin && (
          <div className="chat-sidebar-footer">
            <button
              className={`ctx-toggle-btn ${showContext ? "active" : ""}`}
              onClick={() => setShowContext((v) => !v)}
            >
              {showContext ? "🔵 Ẩn Context" : "🔍 Xem Context"}
            </button>
          </div>
        )}
      </div>

      <div className="chat-main">
        <div className="chat-main-head">
          <div className="chat-title-row">
            <span className="chat-current-title">{conversationTitle}</span>
            <span className="chat-id-badge">{conversationId?.slice(0, 12)}…</span>
          </div>
        </div>

        <div className="chat-messages">
          {messages.length === 0 ? (
            <div className="chat-empty">
              <div className="chat-empty-icon">🤖</div>
              <div className="chat-empty-text">Hãy bắt đầu cuộc trò chuyện!</div>
              <div className="chat-empty-sub">
                Tiêu đề sẽ tự lấy từ câu hỏi đầu tiên, giống kiểu ChatGPT.
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <MessageBubble key={msg.id} role={msg.role} content={msg.content} />
            ))
          )}

          {loading && (
            <div className="chat-bubble-row assistant">
              <div className="chat-avatar assistant">🤖</div>
              <div className="chat-bubble-wrap">
                <div className="chat-bubble assistant typing">
                  <span className="dot" />
                  <span className="dot" />
                  <span className="dot" />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <div className="chat-input-area">
          <textarea
            className="chat-input"
            placeholder="Nhập câu hỏi... (Enter để gửi, Shift+Enter xuống dòng)"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
          />
          <button className="chat-send-btn" onClick={handleSend} disabled={!canSend}>
            <span>↑</span>
          </button>
        </div>
      </div>

      {isAdmin && showContext && (
        <div className="chat-context-panel">
          <div className="ctx-panel-head">🔍 Retrieved Context</div>
          {retrievedContext.length === 0 ? (
            <div className="ctx-empty">Chưa có context được retrieve.</div>
          ) : (
            retrievedContext.map((ctx, i) => (
              <div className="ctx-item" key={i}>
                <div className="ctx-num">#{i + 1}</div>
                <div className="ctx-text">{ctx}</div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}