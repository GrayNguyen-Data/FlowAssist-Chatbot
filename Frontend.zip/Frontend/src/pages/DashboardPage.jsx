import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useState, useEffect } from "react";

const STATS_ADMIN = [
  { label: "Tài liệu đã upload", value: "—", icon: "📄", color: "var(--blue)", key: "docs" },
  { label: "Đã ingest vào RAG", value: "—", icon: "🧠", color: "var(--green)", key: "ingested" },
  { label: "Conversations", value: "—", icon: "💬", color: "var(--purple)", key: "convs" },
  { label: "Messages hôm nay", value: "—", icon: "⚡", color: "var(--amber)", key: "msgs" },
];

const STATS_USER = [
  { label: "Conversations của bạn", value: "—", icon: "💬", color: "var(--blue)", key: "convs" },
  { label: "Tin nhắn đã gửi", value: "—", icon: "📨", color: "var(--green)", key: "msgs" },
  { label: "Context retrieved", value: "—", icon: "🔍", color: "var(--purple)", key: "ctx" },
];

const QUICK_ADMIN = [
  { title: "Upload tài liệu", desc: "Thêm tài liệu mới vào knowledge base", icon: "⬆️", to: "/documents", color: "var(--blue)" },
  { title: "Chat với AI", desc: "Kiểm tra bot với tư cách admin", icon: "🤖", to: "/chat", color: "var(--purple)" },
  { title: "Quản lý Documents", desc: "Xem và ingest lại tài liệu hiện có", icon: "📚", to: "/documents", color: "var(--green)" },
];

const QUICK_USER = [
  { title: "Bắt đầu chat", desc: "Hỏi AI assistant bất kỳ điều gì", icon: "💬", to: "/chat", color: "var(--blue)" },
  { title: "Cuộc trò chuyện mới", desc: "Tạo một conversation trống mới", icon: "✨", to: "/chat", color: "var(--purple)" },
];

export default function DashboardPage() {
  const { role, username, isAdmin } = useAuth();
  const stats = isAdmin ? STATS_ADMIN : STATS_USER;
  const quick = isAdmin ? QUICK_ADMIN : QUICK_USER;
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const greeting = () => {
    const h = time.getHours();
    if (h < 12) return "Chào buổi sáng";
    if (h < 18) return "Chào buổi chiều";
    return "Chào buổi tối";
  };

  const timeStr = time.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = time.toLocaleDateString("vi-VN", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  return (
    <div className="page">
      <div className="dash-hero">
        <div className="dash-hero-left">
          <div className="dash-role-badge" data-role={role}>
            {isAdmin ? "🛡️ Admin" : "👤 User"}
          </div>
          <h1 className="dash-greeting">{greeting()}, {username}!</h1>
          <p className="dash-subline">
            {isAdmin
              ? "Bạn có toàn quyền quản lý hệ thống FlowAssist RAG."
              : "FlowAssist sẵn sàng trả lời mọi câu hỏi của bạn."}
          </p>
        </div>
        <div className="dash-clock">
          <div className="clock-time">{timeStr}</div>
          <div className="clock-date">{dateStr}</div>
        </div>
      </div>

      <div className="dash-stats">
        {stats.map((s) => (
          <div className="stat-card" key={s.key}>
            <div className="stat-icon" style={{ background: s.color + "18", color: s.color }}>{s.icon}</div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="dash-section-title">Hành động nhanh</div>
      <div className="dash-quick">
        {quick.map((q) => (
          <Link to={q.to} key={q.title} className="quick-card" style={{ "--qc": q.color }}>
            <div className="quick-icon">{q.icon}</div>
            <div className="quick-body">
              <div className="quick-title">{q.title}</div>
              <div className="quick-desc">{q.desc}</div>
            </div>
            <div className="quick-arrow">→</div>
          </Link>
        ))}
      </div>

      <div className="dash-bottom">
        <div className="card dash-activity">
          <div className="card-head"><span>📋 Hoạt động gần đây</span></div>
          <div className="activity-list">
            {[
              { icon: "💬", text: "Conversation mới được tạo", time: "vừa xong", color: "var(--blue)" },
              { icon: "📄", text: "Hệ thống sẵn sàng", time: "hôm nay", color: "var(--green)" },
              { icon: "🧠", text: "RAG engine đang chạy", time: "liên tục", color: "var(--purple)" },
            ].map((a, i) => (
              <div className="activity-item" key={i}>
                <div className="act-dot" style={{ background: a.color }}>{a.icon}</div>
                <div className="act-text">{a.text}</div>
                <div className="act-time">{a.time}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card dash-system">
          <div className="card-head"><span>⚙️ Trạng thái hệ thống</span></div>
          <div className="system-list">
            {[
              { name: "API Server", status: "online", color: "var(--green)" },
              { name: "RAG Engine", status: "online", color: "var(--green)" },
              { name: "MinIO Storage", status: "online", color: "var(--green)" },
              { name: "Vector DB", status: "online", color: "var(--green)" },
            ].map((s) => (
              <div className="system-item" key={s.name}>
                <div className="sys-name">{s.name}</div>
                <div className="sys-badge" style={{ background: s.color + "20", color: s.color }}>
                  <span className="sys-dot" style={{ background: s.color }} />
                  {s.status}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}